nombre = str(input("Escribimos el nombre del alumno: "))
while nombre.lower() != "fin":
	numero1 = int(input("Escribe la primera nota del 1 al 10"))