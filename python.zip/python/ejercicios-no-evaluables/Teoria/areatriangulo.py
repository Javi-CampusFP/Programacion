base = 4
altura = 6
area = (base * altura) / 2
print("El area del triángulo es: ", area)

# Pedimos al usuario el dato de la base del triangulo
base2 = input("Escriba la base del triangulo: ")

# Pedimos al usuario el dato de la altura del triangulo
lado2 = input ("Escriba la altura del triangulo: ")

# Calculamos cambiando el dato de tipo str a tipo entero
area2 = (int(base2) * int(lado2)) / 2

# Sacamos el dato por pantalla
print("El area del triangulo es: ", area2)