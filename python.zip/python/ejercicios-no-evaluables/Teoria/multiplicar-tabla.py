# Pedir input al usuario
numero = int(input("Escribe un numero: "))

# Iterar el numero hasta llegar al 10
for multiplicacion in range (10):


	multiplicacion = multiplicacion + 1

	resultado = multiplicacion * numero

	print(numero, " x ", multiplicacion, " = ", resultado)