nombre = "Miguel"
edad = 25
print(nombre + " " + str(edad))

a = 4
b = 5

suma = a + b
print("La suma es: ", suma)
c = 1.25
d = 1
suma2 = c + d

print("La segunda suma es: ", suma2)