frase = "Hola! "
repetir = frase * 3
print(repetir)