frase = "En un lugar de la mancha"
print(frase)

longitud = len(frase)

print(frase[1])

print("La cadena tiene una longitud de: ", longitud)